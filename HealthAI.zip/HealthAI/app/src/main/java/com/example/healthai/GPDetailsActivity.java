package com.example.healthai;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class GPDetailsActivity extends AppCompatActivity {

    Button homeButton, editGPDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gp_details);
        homeButton = findViewById(R.id.button_home);
        editGPDetails = findViewById(R.id.button_edit_gp_details);

        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homepageActivityIntent = new Intent(GPDetailsActivity.this, HomescreenActivity.class);
                startActivity(homepageActivityIntent);
            }
        });

        editGPDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent editGPDetailsActivityIntent = new Intent(GPDetailsActivity.this, EditGPDetailsActivity.class);
                startActivity(editGPDetailsActivityIntent);
            }
        });

    }

}
